package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.models.Student;
import com.example.demo.repository.StudentRepository;

@RestController
public class StudentController {
	@Autowired
	StudentRepository students;
	@PostMapping("students/add")
	public String addStudent(Student student)
	{
		try
		{			
			students.save(student);
			return "Record Added into Database";
		}
		catch (Exception ex)
		{
			return ex.getMessage();			
		}
	}
	
	@PostMapping("students/del")
	public String delstudent(Integer id)
	{
		try {
			students.deleteById(id);
			return "deleted";
		}catch(Exception e) {
			 e.getMessage();
		}
		return "hey";
	}
	// Display Data in JSon Format
	@GetMapping("/students")
    public Iterable<Student> getAllStudent() {
        return students.findAll();
	}

}
